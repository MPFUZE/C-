/*Name: Manav Patel
Student ID: 134182203
email: mdpatel30@myseneca.ca
Date: 28-11-2021*/
/*I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.*/


#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<iomanip>
#include <string>
#include <cstring>
#include"Book.h"

using namespace std;

namespace sdds {
	Book::Book() : Publication() {
		M_AuthorName = nullptr;
	}

	void Book::set(const char* authorname) {
		if (M_AuthorName != nullptr)
			delete[] M_AuthorName;
		M_AuthorName = nullptr;

		if (authorname != nullptr && authorname[0] != '\0') {
			M_AuthorName = new char[strlen(authorname) + 1];

			strcpy(M_AuthorName, authorname);
		}
	}
	Book::Book(const Book& Src_book) : Publication(Src_book) {
		if (Src_book.operator bool()) {
			this->set(Src_book.M_AuthorName);
		}
	}
    Book& Book::operator=(const Book& Src_book) {
		if (this != &Src_book) {
			Publication::operator=(Src_book);
			this->set(Src_book.M_AuthorName);
		}

		return (*this);
	}
    Book::~Book() {
		delete[] M_AuthorName;
	}
    char Book::type()const {
		return 'B';
	}

	std::ostream& Book::write(std::ostream& os) const {
		

		Publication::write(os);
		if (M_AuthorName != nullptr && M_AuthorName[0] != '\0') {
			char temp[SDDS_AUTHOR_WIDTH + 1] = {};

			if (Publication::conIO(os)) {
				os << " ";

				if (strlen(M_AuthorName) > SDDS_AUTHOR_WIDTH) {

					for (int i = 0; i < SDDS_AUTHOR_WIDTH; i++) {
						temp[i] = M_AuthorName[i];
					}

					temp[SDDS_AUTHOR_WIDTH] = '\0';

					os << setw(SDDS_AUTHOR_WIDTH) << temp;
				}
				else {
					os << setw(SDDS_AUTHOR_WIDTH) << M_AuthorName;
				}

				os << " |";
			}
			else {
				os << '\t';

				os << M_AuthorName;
				

			}
		}


		return os;
	}

	std::istream& Book::read(std::istream& istr) {
		

		Publication::read(istr);

		char* authorname = nullptr;
		authorname = new char[256];

		delete[] M_AuthorName;

		if (Publication::conIO(istr)) {
			istr.ignore(1, '\n');
			cout << "Author: ";
			istr.getline(authorname, 256, '\n');
		}
		else {
			istr.ignore(1, '\t');
			istr.get(authorname, 256, '\n');
		}

		if (authorname[0] == '\0')
			istr.setstate(ios::failbit);

		if (istr.good()) {
			M_AuthorName = new char[strlen(authorname) + 1];
			strcpy(M_AuthorName, authorname);
		}

		delete[] authorname;
		return istr;
	}

	void Book::set(int member_id) {
		Publication::set(member_id);
		Publication::resetDate();
	}

	Book::operator bool()const {
		return M_AuthorName != nullptr && M_AuthorName[0] != '\0'
			&& Publication::operator bool();
	}

	// HELPER
	ostream& operator<<(ostream& os, const Book& obj) {
		obj.write(os);
		return os;
	}
	istream& operator>>(istream& is, Book& obj) {
		obj.read(is);
		return is;
	}
}

