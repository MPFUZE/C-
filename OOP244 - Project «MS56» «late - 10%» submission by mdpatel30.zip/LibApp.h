/*Name: Manav Patel
Student ID: 134182203
email: mdpatel30@myseneca.ca
Date: 28-11-2021*/
/*I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.*/

#ifndef SDDS_LIBAPP_H
#define SDDS_LIBAPP_H
#include <cstring>
#include "Menu.h"
#include "Publication.h"
#include "Lib.h"
namespace sdds {
   class LibApp {
      char MP_Files[256];
      Publication *PPA[SDDS_LIBRARY_CAPACITY]{};
      int NOLP=0;
      int LLRN=0;
      bool m_changed=false;

      // doubt
      Menu m_publicationMenu{"Choose the type of publication:"};
      
      Menu m_mainMenu{"Seneca Library Application"};

      Menu m_exitMenu{"Changes have been made to the data, what would you like to do?"};
      bool confirm(const char* message);
      void load(); 
      void save();   
      int search(int option,char type);  
      
      void returnPub();  

      void newPublication();

      void removePublication();

      void checkOutPub();

      Publication* getPub(int libRef);

      public:

      LibApp();

      ~LibApp();

      LibApp(const char filename[256]);

      void run();

   };
}
#endif 



