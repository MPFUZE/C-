/*Name: Manav Patel
Student ID: 134182203
email: mdpatel30@myseneca.ca
Date: 28-11-2021*/
/*I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.*/


#ifndef SDDS_UTILS_H
#define SDDS_UTILS_H

namespace sdds {

}

#endif